public class Forecast {

    // Recursive function to calculate future value
    public static double calculateFutureValue(double currentValue, double growthRate, int years) {
        // Base case
        if (years == 0) {
            return currentValue;
        }
        // Recursive case
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double initialValue = 10000.0; // starting amount
        double growthRate = 0.08;      // 8% annual growth
        int years = 5;                 // forecast 5 years

        double futureValue = calculateFutureValue(initialValue, growthRate, years);

        System.out.printf("The predicted future value after %d years is: ₹%.2f\n", years, futureValue);
    }
}
