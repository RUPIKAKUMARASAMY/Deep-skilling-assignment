package com.library.service;

import com.library.repository.LibraryRepository;

public class LibraryService {
    private LibraryRepository libraryRepository;

    // Setter for Dependency Injection
    public void setLibraryRepository(LibraryRepository libraryRepository) {
        this.libraryRepository = libraryRepository;
    }

    public void processItem(String itemName) {
        System.out.println("Processing item: " + itemName);
        libraryRepository.save(itemName);
    }
}
