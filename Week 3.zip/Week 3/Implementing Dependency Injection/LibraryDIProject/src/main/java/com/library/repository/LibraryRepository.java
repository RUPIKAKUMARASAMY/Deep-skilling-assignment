package com.library.repository;

public class LibraryRepository {
    public void save(String item) {
        System.out.println("Saved to library database: " + item);
    }
}
